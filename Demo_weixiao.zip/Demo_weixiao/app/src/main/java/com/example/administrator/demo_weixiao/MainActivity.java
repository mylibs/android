package com.example.administrator.demo_weixiao;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findview();


    }

    private void findview() {
        Button btnDemo1 = (Button) findViewById(R.id.demo1);
        btnDemo1.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.demo1:
                Intent intent = new Intent(this, Demo001Activity.class);
                startActivity(intent);
                break;


            default:
                break;
        }


    }


}
